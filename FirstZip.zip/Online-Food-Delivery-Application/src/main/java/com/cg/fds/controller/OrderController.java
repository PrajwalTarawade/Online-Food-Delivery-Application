package com.cg.fds.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fds.entities.Customer;
import com.cg.fds.entities.OrderDetails;
import com.cg.fds.entities.Restaurant;
import com.cg.fds.service.IOrderService;

@RestController
public class OrderController {
	@Autowired
	IOrderService orderservice;

	@PostMapping("/addOrder")
	public ResponseEntity<OrderDetails> addOrder(@RequestBody OrderDetails order)
	{
	    OrderDetails order2 =orderservice.addOrder(order);
		return new ResponseEntity<OrderDetails>(order2,HttpStatus.OK);
	}
	
	@PutMapping("/updateOrder")
	public ResponseEntity<OrderDetails> updateOrder(@RequestBody OrderDetails order)
	{
	    OrderDetails order2 =orderservice.updateOrder(order);
		return new ResponseEntity<OrderDetails>(order2,HttpStatus.OK);
	}
	
	@DeleteMapping("/removeOrderByOrderId/{oid}")
	public  ResponseEntity<String> removeOrder(@PathVariable int oid) 
	{
	       String msg=orderservice.removeOrder(oid);
			return new ResponseEntity<String>(msg, HttpStatus.OK);
	}
	
	@GetMapping("/viewOrderByOrderId/{oid}")
	public ResponseEntity<OrderDetails> viewOrder(@PathVariable int oid) 
	{
		OrderDetails order2 = orderservice.viewOrder(oid);
		return new ResponseEntity<OrderDetails>(order2, HttpStatus.OK);
	}
	
	@GetMapping("/viewAllOrdersByRestaurant/{resName}")
	public ResponseEntity<List<OrderDetails>> viewAllOrdersByRestaurant(@PathVariable String resName) 
	{
		List<OrderDetails> order2 = orderservice.viewAllOrdersByRestaurant(resName);
		return new ResponseEntity<List<OrderDetails>>(order2, HttpStatus.OK);
	}
	
	@GetMapping("/viewAllOrders/{id}")
	public ResponseEntity<List<OrderDetails>> viewAllOrders(@PathVariable int id) 
	{
		List<OrderDetails> order2 = orderservice.viewAllOrders(id);
		return new ResponseEntity<List<OrderDetails>>(order2, HttpStatus.OK);
	}
	
	
}
