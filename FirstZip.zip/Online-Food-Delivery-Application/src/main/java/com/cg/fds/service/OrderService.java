package com.cg.fds.service;
import java.util.ArrayList;
import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fds.entities.Customer;
import com.cg.fds.entities.Item;
import com.cg.fds.entities.OrderDetails;
import com.cg.fds.entities.Restaurant;
import com.cg.fds.repositories.IOrderRepository;

@Service
@Transactional
public class OrderService implements IOrderService{
	
	@Autowired
	IOrderRepository repository;

	@Override
	public OrderDetails addOrder(OrderDetails order) {
		// TODO Auto-generated method stub
		repository.save(order);
		return order;
		
	}

	@Override
	public OrderDetails updateOrder(OrderDetails order) {
		// TODO Auto-generated method stub
		OrderDetails order1=repository.save(order);
		return order1;
	}

	@Override
	public String removeOrder(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
		
		return "Order removed successfully...";
		
	}

	@Override
	public OrderDetails viewOrder(int id) {
		// TODO Auto-generated method stub
		OrderDetails order=repository.findById(id).orElse(null);
		System.out.println(order);
		return order;
	}
/*
	@Override
	public List<OrderDetails> viewAllOrders(Restaurant resName) {
		// TODO Auto-generated method stub
		//List<OrderDetails> order = repository.findAll(resName);
		return null;
	}
*/
	@Override
	public List<OrderDetails> viewAllOrders(Customer customer) {
		// TODO Auto-generated method stub
		
		/*int id= customer.getCustomerId();
		//List<OrderDetails> order = repository.findAll(customer);
		List<Integer> list = repository.findAll(id);
		List<OrderDetails> list1 = new ArrayList<OrderDetails>();
		
		for(int i = 0; i < list.size(); i++)
        {
           int it=list.get(i);
          // OrderDetails b2= new OrderDetails();
           OrderDetails b=repository.findById(it).orElse(null);
           
           System.out.println(b);
          list1.add(b);          
          
        }
        */
		return null;
		
	}

	@Override
	public List<OrderDetails> viewAllOrders(int id) {
		// TODO Auto-generated method stub
	
		//List<OrderDetails> order = repository.findAll(customer);
		List<Integer> list = repository.findAll(id);
		List<OrderDetails> list1 = new ArrayList<OrderDetails>();
		
		for(int i = 0; i < list.size(); i++)
        {
           int it=list.get(i);
          // OrderDetails b2= new OrderDetails();
           OrderDetails b=repository.findById(it).orElse(null);
           
           System.out.println(b);
          list1.add(b);          
          
        }
		return list1;
		
		
	}

	@Override
	public List<OrderDetails> viewAllOrdersByRestaurant(String resName) {
		// TODO Auto-generated method stub
		//int id = resName.getRestaurantId();
		List<Integer> list = repository.findAllByRestaurant(resName);
		
		List<OrderDetails> list1 = new ArrayList<OrderDetails>();
		
		for(int i = 0; i < list.size(); i++)
        {
           int it=list.get(i);
          // OrderDetails b2= new OrderDetails();
           OrderDetails b=repository.findById(it).orElse(null);
           
           System.out.println(b);
          list1.add(b);          
          
        }
		return list1;
	}
	
}

	
	
