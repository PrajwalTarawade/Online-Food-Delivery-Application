package com.cg.fds.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fds.entities.CustomerLogin;
import com.cg.fds.entities.RestaurantLogin;
import com.cg.fds.repositories.ICustomerLoginRepository;

import antlr.collections.List;


@Service
@Transactional
public class CustomerLoginService implements ICustomerLogin {
	@Autowired
	ICustomerLoginRepository repository;
	

	@Override
	public CustomerLogin addCustomerLogin(CustomerLogin login) {
	repository.save(login);
		return login;
	}

	@Override
	public java.util.List<CustomerLogin> deleteCustomerLogin(int userid) {
		// TODO Auto-generated method stub
		repository.deleteById(userid);
		return repository.findAll();
	}
	@Override
	public String CustomerLogin(String username, String password) {
		CustomerLogin r=repository.findByUserName(username);
		String pwd=r.getPassword();
		String login1="Login Successfull";
		String loginFail="Invalid Password";
		if(pwd.equals(password))
		     return login1;
		else
			return loginFail;
		
	}
	@Override
	public CustomerLogin updateCustomerLogin(CustomerLogin login) {
		repository.save(login);
		return login;	
	}
	@Override
	public String CustomerLogout() {
		String logout="Logout Successfull ";
		return logout;
	}

	

	
}


