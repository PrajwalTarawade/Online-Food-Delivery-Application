package com.cg.fds.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.Item;
import com.cg.fds.service.ICartService;

@RestController
public class CartController {

	@Autowired
	ICartService CService;
	
	@PostMapping("/addItemToCart")
	public ResponseEntity<FoodCart> addItemToCart(@RequestBody FoodCart cart, @RequestParam("itemId") int itemId){
		//FoodCart cart1 = CService.addItemToCart(cart, itemId);
		return null;//new ResponseEntity<FoodCart>(cart1, HttpStatus.OK);
	}
	
	@PutMapping("/increaseQuantity/{quantity}")
	public ResponseEntity<FoodCart> increaseQuantity(@RequestBody FoodCart cart, @RequestBody Item item, @PathVariable int quantity){
		
		return null;
	}
	
	@PutMapping("/reduceQuantity/{quantity}")
	public ResponseEntity<FoodCart>  reduceQuantity(@RequestBody FoodCart cart, @RequestBody Item item, int quantity){
		
		return null;
	}
	
	@DeleteMapping("/removeItem")
	public ResponseEntity<FoodCart> removeItem(@RequestBody FoodCart cart, @RequestBody Item item){
		
		return null;
	}
	
	@DeleteMapping("/clearCart")
	public ResponseEntity<FoodCart>  clearCart(@RequestBody FoodCart cart){
		return null;
	}
	
	@PostMapping("/createCart")
	public ResponseEntity<FoodCart> createCart(@RequestBody FoodCart cart){
		//FoodCart cart1 = CService.createCart(cart);
		return null;// new ResponseEntity<FoodCart>(cart1, HttpStatus.OK);
	}
}
