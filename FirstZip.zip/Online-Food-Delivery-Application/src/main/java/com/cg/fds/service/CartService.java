package com.cg.fds.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.Item;
import com.cg.fds.repositories.ICartRepository;

@Service
@Transactional
public class CartService implements ICartService{

	@Autowired
	ICartRepository repository;
	
	
	public CartService() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public FoodCart addItemToCart(FoodCart cart, Item item) {
		cart.getItemList().add(item);
		FoodCart cart1=repository.save(cart);
		return cart1;
	}

	@Override
	public FoodCart increaseQuantity(int cartId, int itemId, int quantity) {
		//System.out.println("****"+itemId+"=="+quantity);
		//List<Item> itemList=cart.getItemList();
		//System.out.println(itemList);
		FoodCart cart=repository.findById(cartId).orElse(null);
		List<Item> itemList=cart.getItemList();
		System.out.println("****"+itemList);
		Item i=itemList.get(itemId);
		System.err.println(i);
		i.setQuantity(quantity);
		cart.getItemList().add(i);
		return repository.save(cart);
	}

	@Override
	public FoodCart reduceQuantity(FoodCart cart, Item item, int quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String removeItem(FoodCart cart, int itemId) {
		List<Item> list=cart.getItemList();
		if(list.contains(itemId))
		{
			list.remove(itemId);
			return "Item removed successfully...";
		}
		else
		{
			return "Item not present in cart...";
		}
		
	}
	
	@Override
	public FoodCart clearCart(FoodCart cart) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FoodCart getCartById(int cartId) {
		FoodCart cart=repository.findById(cartId).orElse(null);
		return cart;
	}

	@Override
	public Item getItemById(int itemId) {
		//Item item=repository.getOne(itemId);
		return null;
	}

	
}
