package com.cg.fds.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Item {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int itemId;
	private String itemName;
	private int quantity;
	private double cost;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="catId")
	private Category category;
	
	
	 @ManyToOne
	 @JoinColumn(name = "restaurantId")
	 private Restaurant restaurant;
	   
	
	@ManyToOne
    @JoinColumn(name="cartId")
    FoodCart cart;


	public Item(int itemId, String itemName, int quantity, double cost, Category category, Restaurant restaurant,
			FoodCart cart) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.quantity = quantity;
		this.cost = cost;
		this.category = category;
		this.restaurant = restaurant;
		this.cart = cart;
	}


	public Item() {
		super();
	}


	public int getItemId() {
		return itemId;
	}


	public void setItemId(int itemId) {
		this.itemId = itemId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public double getCost() {
		return cost;
	}


	public void setCost(double cost) {
		this.cost = cost;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	public Restaurant getRestaurant() {
		return restaurant;
	}


	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}


	public FoodCart getCart() {
		return cart;
	}


	public void setCart(FoodCart cart) {
		this.cart = cart;
	}
	

	
	
}
