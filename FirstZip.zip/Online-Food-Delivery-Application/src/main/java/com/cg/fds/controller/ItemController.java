package com.cg.fds.controller;

import java.util.ArrayList;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fds.entities.Category;
import com.cg.fds.entities.Item;
import com.cg.fds.entities.Restaurant;
import com.cg.fds.service.IItemService;

@RestController
public class ItemController 
{
	@Autowired
	IItemService itemservice;

	@PostMapping("/addItem")
	public ResponseEntity<Item> addItem(@RequestBody Item item)
	{
	    Item item2 =itemservice.addItem(item);
		return new ResponseEntity<Item>(item2,HttpStatus.OK);
	}
	
	@PutMapping("/updateItem")
	public ResponseEntity<Item> updateItem(@RequestBody Item item)
	{
	    Item item2 =itemservice.updateItem(item);
		return new ResponseEntity<Item>(item2,HttpStatus.OK);
	}
	
	@DeleteMapping("/removeItemByItemId/{iid}")
	public ResponseEntity<String> removeItem(@PathVariable int iid) 
	{
		String msg=itemservice.removeItem(iid);
		return new ResponseEntity<String>(msg, HttpStatus.OK);
		 
	}
	
	@GetMapping("/viewItemByItemId/{iid}")
	public ResponseEntity<Item> viewItem(@PathVariable int iid) 
	{
		Item item2 = itemservice.viewItem(iid);
		return new ResponseEntity<Item>(item2, HttpStatus.OK);
	}

	@GetMapping("/viewAllItemsByCategory/{id}")
	public ResponseEntity<List<Item>> viewAllItemsByCategory(@PathVariable int id) 
	{
		
		List<Item> item2 = itemservice.viewAllItemsByCategory(id); 
        return new ResponseEntity<List<Item>>(item2, HttpStatus.OK);
      
	}
	/*
	@GetMapping("/viewAllByRestaurant")
	public ResponseEntity<List<Item>> viewAllByRestaurant(@RequestBody Restaurant res)
	{
		List<Item> list = itemservice.viewAllByRestaurant(res);
		return new ResponseEntity<List<Item>>(list, HttpStatus.OK);
	}
	*/

}
