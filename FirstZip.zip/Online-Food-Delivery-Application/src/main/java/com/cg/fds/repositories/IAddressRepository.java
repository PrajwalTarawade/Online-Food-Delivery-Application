package com.cg.fds.repositories;

public interface IAddressRepository {

}
