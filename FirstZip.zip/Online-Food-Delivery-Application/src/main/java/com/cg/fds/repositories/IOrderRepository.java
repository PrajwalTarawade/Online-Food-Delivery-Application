package com.cg.fds.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.fds.entities.Customer;
import com.cg.fds.entities.OrderDetails;
import com.cg.fds.entities.Restaurant;

@Repository
public interface IOrderRepository extends JpaRepository<OrderDetails, Integer> {

	/*

	public List<OrderDetails> findAll(Restaurant resName);
*/
	@Query("select o.orderId from OrderDetails o inner join FoodCart f "
			+ "ON o.cart.cartId=f.cartId INNER JOIN Customer c "
			+ "ON f.customer.customerId=c.customerId where c.customerId = ?1")
	public List<Integer> findAll(int id);

	@Query("select o.orderId from OrderDetails o inner join FoodCart f "
			+ "ON o.cart.cartId=f.cartId INNER JOIN Item i "
			+ "ON f.cartId=i.cart.cartId INNER JOIN Restaurant r "
			+ "ON i.restaurant.restaurantId=r.restaurantId "
			+ "where r.restaurantName= ?1")
	public List<Integer> findAllByRestaurant(String resName);
	

	
}
