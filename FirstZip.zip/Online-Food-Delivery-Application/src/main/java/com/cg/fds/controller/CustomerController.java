package com.cg.fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fds.entities.Customer;
import com.cg.fds.service.ICustomerService;

@RestController
public class CustomerController {

	@Autowired
	ICustomerService service;
	
	@PostMapping("/addCustomer")
	public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer)
	{
	    Customer customer2=service.addCustomer(customer);
		return new ResponseEntity<Customer>(customer2,HttpStatus.OK);
	}
	
	@PutMapping("/updateCustomer")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer)
	{
	    Customer customer2=service.updateCustomer(customer);
		return new ResponseEntity<Customer>(customer2,HttpStatus.OK);
	}
	
	@DeleteMapping("/removeCustomer/{id}")
	public ResponseEntity<String> deleteCustomer(@PathVariable int id)
	{
	    String result=service.removeCustomerById(id);
		return new ResponseEntity<String>(result,HttpStatus.OK);
	}
	
	@GetMapping("/viewCustomer/{id}")
	public ResponseEntity<Customer> viewCustomer(@PathVariable int id)
	{
	    Customer customer=service.viewCustomer(id);
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}
	
	@GetMapping("/viewAllCustomer/{name}")
	public ResponseEntity<List<Customer>> viewAllCustomer(@PathVariable String name)
	{
	    List<Customer> customer=service.viewAllCustomer(name);
		return new ResponseEntity<List<Customer>>(customer,HttpStatus.OK);
	}
}
