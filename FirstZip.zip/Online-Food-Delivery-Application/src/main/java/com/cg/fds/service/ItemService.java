package com.cg.fds.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fds.entities.Category;
import com.cg.fds.entities.Item;
import com.cg.fds.entities.Restaurant;
import com.cg.fds.repositories.IItemRepository;

@Service
@Transactional
public class ItemService implements IItemService{

	@Autowired
	IItemRepository repository;
	
	@Override
	public Item addItem(Item item) {
		Item item1 = repository.save(item);	
		return item1;
	}

	@Override
	public Item viewItem(int id) {
		Item item = repository.findById(id).orElse(null);
		return item;	
	}

	@Override
	public Item updateItem(Item item) {
		Item item1=repository.save(item);
		return item1;
	}

	@Override
	public String removeItem(int id) {
		repository.deleteById(id);
		return "Item removed successfully...";
	}

	@Override
	public List<Item> viewAllItems(Restaurant res) {
		return null;
	}

	@Override
	public List<Item> viewAllItemsByCategory(int id) {
//		List<Integer> list = repository.findAll(id);
//		List<Item> list1 = new ArrayList<Item>();
//		
//		for(int i = 0; i < list.size(); i++)
//        {
//           int it=list.get(i);
//           Item b=repository.findById(it).orElse(null);
//           
//           System.out.println(b);
//          list1.add(b);          
//          
//        }
//		return list1;
		return null;
	}

	@Override
	public List<Item> viewAllItemsByName(String name) {
		return null;
	}

}
