package com.cg.fds.service;

import com.cg.fds.entities.Customer;
import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.Item;

public interface ICartService {

	public FoodCart addItemToCart(FoodCart cart,Item item);
	public FoodCart increaseQuantity(int cartId,int itemId,int quantity);
	public FoodCart reduceQuantity(FoodCart cart,Item item,int quantity);
	public String removeItem(FoodCart cart,int itemId);
	public FoodCart clearCart(FoodCart cart);
	public FoodCart getCartById(int cartId);
	public Item getItemById(int itemId);
	
	
}
