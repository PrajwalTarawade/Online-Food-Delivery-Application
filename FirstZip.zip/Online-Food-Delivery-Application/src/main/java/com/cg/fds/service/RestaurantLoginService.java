package com.cg.fds.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fds.entities.RestaurantLogin;
import com.cg.fds.repositories.IRestaurantLoginRepository;

@Service
@Transactional
public class RestaurantLoginService implements IRestaurantLogin {
	@Autowired
	IRestaurantLoginRepository repository;
	@Override
	public RestaurantLogin addRestaurantLogin(RestaurantLogin login) {

		repository.save(login);
		return login;
}
	@Override
	public List<RestaurantLogin> deleteRestaurantLogin(int userid) {
        repository.deleteById(userid);
		return repository.findAll();
	}
	@Override
	public String candidateLogin(String username, String password) {
		RestaurantLogin r=repository.findByUserName(username);
		String pwd=r.getPassword();
		String login1="Login Successfull";
		String loginFail="Invalid Password";
		if(pwd.equals(password))
		     return login1;
		else
			return loginFail;
		
	}
	@Override
	public RestaurantLogin updateRestaurantLogin(RestaurantLogin login) {

		repository.save(login);
		return login;	
	}
	@Override
	public String candidateLogout() {
		String logout="Logout Successfull ";
		return logout;
	}
}
	
	

	
