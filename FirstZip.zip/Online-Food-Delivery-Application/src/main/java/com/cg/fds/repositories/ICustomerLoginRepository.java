package com.cg.fds.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.fds.entities.CustomerLogin;
import com.cg.fds.entities.RestaurantLogin;

@Repository
public interface ICustomerLoginRepository extends JpaRepository<CustomerLogin, Integer> {
	
	public CustomerLogin findByUserName(String userName);

}
