package com.cg.fds.service;
import java.util.List;

import com.cg.fds.entities.CustomerLogin;



public interface ICustomerLogin {
	public CustomerLogin addCustomerLogin(CustomerLogin login);
	public CustomerLogin updateCustomerLogin(CustomerLogin login);
	public  List<CustomerLogin> deleteCustomerLogin(int userid);
	public String CustomerLogin(String username,String password);
	public String CustomerLogout();
}
