package com.cg.fds.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fds.entities.Bill;
import com.cg.fds.entities.Customer;
import com.cg.fds.entities.FoodCart;
import com.cg.fds.repositories.IBillRepository;
@Service
@Transactional
public class BillService implements IBillService {
	@Autowired
    IBillRepository repository;
	Customer customer;
	FoodCart foodCart;
	@Override
	public Bill addBill(Bill bill) {
	    repository.save(bill);
		return bill;
	}

	@Override
	public String removeBill(Bill bill) {
		repository.delete(bill);
		String s="Bill removed Succesfully";
		return s;
	}

	@Override
	public Bill viewBillById(int id) {
		Bill b=repository.findById(id).orElse(null);
		System.out.println(b);
		return b;
		
	}

	@Override
	public List<Bill> viewBills(LocalDate startDate, LocalDate endDate) {
        LocalDateTime startDateTime = startDate.atTime(0,0, 0);
        LocalDateTime endDateTime = endDate.atTime(23,59,59);
        List<Bill> bill1= new ArrayList<Bill>();
        List<Integer> bill=repository.findByBillDates(startDateTime, endDateTime);
        for(int i = 0; i < bill.size(); i++){
           int id=bill.get(i);
           Bill b=repository.findById(id).orElse(null);
           System.out.println(b);
           bill1.add(b);           
        }
        return bill1;
    }

	@Override
	public List<Bill> viewBills(int custId) {
		List<Bill> bill1= new ArrayList<Bill>();	
		List<Integer> bill=repository.findByCustId(custId);
		for(int i = 0; i < bill.size(); i++){
		   int id=bill.get(i);
		   Bill b=repository.findById(id).orElse(null);
		   System.out.println(b);
		   bill1.add(b);		   
		}
        return bill1;
	}

	@Override
	public String calculateTotalCost(int id) {
		Bill bill=repository.findById(id).orElse(null);
		Double totalCost=bill.getTotalCost();
		StringBuffer sb=new StringBuffer("Total cost of bill is ");
		sb.append(totalCost);
		String msg=sb.toString();
		return msg;
	}
	
}
