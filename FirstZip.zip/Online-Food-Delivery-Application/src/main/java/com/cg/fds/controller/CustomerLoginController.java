package com.cg.fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fds.entities.CustomerLogin;
import com.cg.fds.service.CustomerLoginService;
import com.cg.fds.service.ICustomerLogin;


@RestController
public class CustomerLoginController {
	@Autowired
	ICustomerLogin service;
	@PostMapping("/addCustLogin")
	public ResponseEntity<CustomerLogin> addCustomerLogin(@RequestBody CustomerLogin login) {
				CustomerLogin loginData = service.addCustomerLogin(login);
		return new ResponseEntity<CustomerLogin>(loginData, HttpStatus.OK);
	}
	@PutMapping("/updateCustLogin")
	public ResponseEntity<CustomerLogin> updateCustomerLogin(@RequestBody CustomerLogin login) {
		CustomerLogin loginData = service.updateCustomerLogin(login);
		return new ResponseEntity<CustomerLogin>(loginData, HttpStatus.OK);
	}
	@DeleteMapping("/deleteCustLogin/{userid}")
	public ResponseEntity<List<CustomerLogin>> deleteCustomerLogin(@PathVariable int userid) {
	List<CustomerLogin> custList =  service.deleteCustomerLogin(userid);
		return new ResponseEntity<List<CustomerLogin>>(custList, HttpStatus.OK);
}
	@GetMapping("/customerLogin/{username}/{password}")
	public ResponseEntity<String> CustomerLogin(@PathVariable String username,@PathVariable String password) 
	{
		String login=service.CustomerLogin(username,password);
		return new ResponseEntity<String>(login, HttpStatus.OK);
	}
	@GetMapping("/customerLogout")
	public ResponseEntity<String> candidateLogout() 
	{
		String logout=service.CustomerLogout();
		return new ResponseEntity<String>(logout, HttpStatus.OK);
	}
}

