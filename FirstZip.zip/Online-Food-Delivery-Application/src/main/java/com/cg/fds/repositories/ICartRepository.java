package com.cg.fds.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.Item;

@Repository
public interface ICartRepository  extends JpaRepository<FoodCart, Integer>{
	
	//@Query("SELECT i from item i INNER JOIN food_cart f	on i.cart_id=f.cart_id where i.item_id=:itemId")
	//public Item getItemById(int itemId);

}
