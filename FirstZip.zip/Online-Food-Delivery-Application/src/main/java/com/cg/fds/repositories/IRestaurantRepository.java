package com.cg.fds.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.cg.fds.entities.Restaurant;

@Repository
public interface IRestaurantRepository extends JpaRepository<Restaurant, Integer> {
	
	@Query("select r from Restaurant r inner join Item i on r.restaurantId = i.restaurant where i.itemName = ?1 ")
	public List<Restaurant> viewRestaurantByItemName(String itemName);
//	@Query("select r from Restaurant r where (r.address = (select a.addressId from Address a where (a.area = ?1)))")
	@Query("select r from Restaurant r inner join Address a on r.address = a.addressId where a.area =?1")
	public List<Restaurant> viewNearByRestaurant(String location);
	

		
}
