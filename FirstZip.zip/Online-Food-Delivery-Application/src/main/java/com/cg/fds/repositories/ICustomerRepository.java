package com.cg.fds.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.fds.entities.Customer;

@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Integer>{

	@Query("select c from Customer c"
			+ " inner join FoodCart f on c.customerId=f.customer.customerId"
			+ " inner join Item i on f.cartId=i.cart.cartId"
			+ " inner join Restaurant r on i.restaurant=r.restaurantId where r.restaurantName=?1")
	List<Customer> findByRestaurantName(String restaurantName);
	
}
