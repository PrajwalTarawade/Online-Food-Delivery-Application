package com.cg.fds.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fds.entities.Category;
import com.cg.fds.repositories.ICategoryRepository;
@Service
@Transactional
public class CategoryService implements ICategoryService {
	@Autowired
    ICategoryRepository repository;
	@Override
	public Category addCategory(Category cat) {
		repository.save(cat);
		return cat;
	}

	@Override
	public Category updateCategory(Category cat) {
		repository.save(cat);
		return cat;
	}

	@Override
	public Category removeCategory(Category cat) {
		repository.delete(cat);
		return cat;
	}

	@Override
	public Category viewCategory(int id) {
		
		Category c=repository.findById(id).orElse(null);
		return c;
	}

	@Override
	public List<Category> viewAllCategory() {
		List<Category> cat=repository.findAll();
		return cat;
	}

}
