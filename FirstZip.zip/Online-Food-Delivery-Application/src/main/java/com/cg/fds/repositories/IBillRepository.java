package com.cg.fds.repositories;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.fds.entities.Bill;
import java.time.LocalDateTime;
public interface IBillRepository extends JpaRepository<Bill, Integer> {
     @Query("select b.billId from Bill b "
     		+ "JOIN OrderDetails o "
     		+ "ON b.order.orderId=o.orderId "
     		+ "JOIN FoodCart c "
     		+ "ON o.cart.cartId=c.cartId "
     		+ "WHERE c.customer.customerId = ?1")
    List<Integer> findByCustId(int custId);
	
     @Query("select b.billId from Bill b "
             + "JOIN OrderDetails o "
             + "ON b.order.orderId=o.orderId "
             + "WHERE o.OrderDate BETWEEN ?1 AND ?2 ")
    public List<Integer> findByBillDates(LocalDateTime start, LocalDateTime end);
}
