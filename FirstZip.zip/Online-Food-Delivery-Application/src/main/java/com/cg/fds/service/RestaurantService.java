package com.cg.fds.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fds.entities.Restaurant;
import com.cg.fds.repositories.IRestaurantRepository;

@Service
@Transactional
public class RestaurantService implements IRestaurantService {

	@Autowired
	IRestaurantRepository repository;
	
	@Override
	public Restaurant addRestaurant(Restaurant res) {
		repository.save(res);
		return res;
	}

	@Override
	public Restaurant updateRestaurant(Restaurant restaurant) {
				return repository.save(restaurant);
	}
	
	@Override
	public String removeRestaurantById(int Rid) {
		repository.deleteById(Rid);
		return "Restaurant deleted Successfully";
	}

	@Override
	public List<Restaurant> viewAllRestaurants() {
		return repository.findAll();
	}
	
	@Override
	public Restaurant viewRestaurantById(int id) {
		Restaurant restaurant = repository.findById(id).orElse(null);
		return restaurant;	
	}



	@Override
	public List<Restaurant> viewNearByRestaurant(String location) {
		List<Restaurant> list = repository.viewNearByRestaurant(location);
		return list;
	}


	@Override
	public List<Restaurant> viewRestaurantByItemName(String restaurantName) {
		return repository.viewRestaurantByItemName(restaurantName);
	}

	
	
}
