package com.cg.fds.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fds.entities.Bill;
import com.cg.fds.service.IBillService;


@RestController
public class BillController {
	@Autowired
	IBillService service;
	
	@PostMapping("/addBill")
	public ResponseEntity<Bill> addBill(@RequestBody Bill bill)
	{ 
		Bill bill2=service.addBill(bill);
		return new ResponseEntity<Bill>(bill2,HttpStatus.OK);
		
	}
	@DeleteMapping("/removeBill")
	public ResponseEntity<String> removeBill(@RequestBody Bill bill)
	{ 
		String bill2=service.removeBill(bill);
		return new ResponseEntity<String>(bill2,HttpStatus.OK);
		
	}
	@GetMapping("/viewBillByBillId/{id}")
	public ResponseEntity<Bill> viewBill(@PathVariable int id)
	{ 
		Bill bill2=service.viewBillById(id);
		return new ResponseEntity<Bill>(bill2,HttpStatus.OK);
		
	}
	@GetMapping("/viewBillByCustomerId/{id}")
	public ResponseEntity<List<Bill>> viewBills(@PathVariable int id){
		List<Bill> billList = service.viewBills(id);
	
	
		return new ResponseEntity<List<Bill>>(billList, HttpStatus.OK);
	}
	@GetMapping("/viewBillByOrderDate/{startDate}/{endDate}")
	
	public ResponseEntity<List<Bill>> viewBills(@PathVariable String startDate, @PathVariable String endDate){
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate startDate1 = LocalDate.parse(startDate, dateTimeFormatter);
		LocalDate endDate1 = LocalDate.parse(endDate, dateTimeFormatter);
		List<Bill> billList = service.viewBills(startDate1,endDate1);
	
		return new ResponseEntity<List<Bill>>(billList, HttpStatus.OK);
	}
	@GetMapping("/calculateTotalCost/{id}")
	public ResponseEntity<String> calculateTotalCost(@PathVariable int id){
		String billList = service.calculateTotalCost(id);
	    return new ResponseEntity<String>(billList, HttpStatus.OK);
	    
	}
}

