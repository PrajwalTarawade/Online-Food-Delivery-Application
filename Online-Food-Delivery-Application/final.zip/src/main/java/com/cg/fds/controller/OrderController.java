package com.cg.fds.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.OrderDetails;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.exceptions.invalidNameException;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.service.ICartService;
import com.cg.fds.service.IOrderService;

@RestController
public class OrderController {
	
	@Autowired
	IOrderService orderservice;
	
	@Autowired
	ICartService cartService;

	@PostMapping("/addOrder/{cart_id}")
	public ResponseEntity<OrderDetails> addOrder(@PathVariable int cartId)
	{
		OrderDetails order2 =orderservice.addOrder(cartId);
	   	return new ResponseEntity<OrderDetails>(order2,HttpStatus.OK);
	}
	
	@PutMapping("/updateOrder")
	public ResponseEntity<OrderDetails> updateOrder(@Valid @RequestBody OrderDetails order) throws IdNotFoundException
	{
		OrderDetails order1=orderservice.viewOrderById(order.getOrderId());
		if(order1==null)
		{
			throw new IdNotFoundException("Unable to update order due to invalid input !!!");
		}
		else
		{
			OrderDetails order2 =orderservice.updateOrder(order);
			return new ResponseEntity<OrderDetails>(order2,HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/removeOrderByOrderId/{Order_id}")
	public  ResponseEntity<String> removeOrder(@PathVariable("Order_id") int oid) throws removeFailedException 
	{
		   OrderDetails order1=orderservice.viewOrderById(oid);
	       if(order1==null)
		   {
	    	   throw new removeFailedException("Order removal failed !!!");
	       }
	       else
	       {
	    	   String msg=orderservice.removeOrderById(order1);
	    	   return new ResponseEntity<String>(msg, HttpStatus.OK);
	       }
	}
	
	@GetMapping("/viewOrderByOrderId/{Order_id}")
	public ResponseEntity<OrderDetails> viewOrder(@PathVariable("Order_id") int oid) throws IdNotFoundException 
	{
		OrderDetails order2 = orderservice.viewOrderById(oid);
		if(order2==null)
		{
			throw new IdNotFoundException("Order id not found !!!");
		}
		else
		{
			return new ResponseEntity<OrderDetails>(order2, HttpStatus.OK);
		}
	
	}
	
	@GetMapping("/viewAllOrdersByRestaurant/{Restaurant_name}")
	public ResponseEntity<List<OrderDetails>> viewAllOrdersByRestaurant(@PathVariable("Restaurant_name") String resName) throws invalidNameException 
	{
		List<OrderDetails> order2 = orderservice.viewAllOrdersByRestaurant(resName);
		if(order2.isEmpty())
		{
			throw new invalidNameException("Invalid restaurant name !!!");
		}
		else
		{
			return new ResponseEntity<List<OrderDetails>>(order2, HttpStatus.OK);

		}
	}
	
	@GetMapping("/viewAllOrdersByCustomer/{Customer_id}")
	public ResponseEntity<List<OrderDetails>> viewAllOrdersByCustomer(@PathVariable("Customer_id") int id) throws IdNotFoundException 
	{
		List<OrderDetails> order2 = orderservice.viewAllOrdersByCustomer(id);
		if(order2.isEmpty())
		{
			throw new IdNotFoundException("Invalid customer !!!");
		}
		else
		{
			return new ResponseEntity<List<OrderDetails>>(order2, HttpStatus.OK);
		}
	}
	
	
}
