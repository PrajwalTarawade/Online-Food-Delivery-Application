package com.cg.fds.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fds.entities.Bill;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.service.IBillService;


@RestController
public class BillController {
	
	@Autowired
	IBillService service;
	
	@PostMapping("/addBill/{Order_id}")
	public ResponseEntity<Bill> addBill(@PathVariable("Order_id") int id) throws IdNotFoundException
	{ 
		Bill bill2=service.addBill(id);
		if(bill2==null)
		{
			throw new IdNotFoundException("Cannot add order");
		}
		else
		return new ResponseEntity<Bill>(bill2,HttpStatus.OK);
		
	}
		
	@DeleteMapping("/removeBill/{id}")
	public ResponseEntity<String> removeBill(@PathVariable int id) throws removeFailedException
	{ 
		Bill bill=service.viewBillById(id);
		if(bill==null)
		{
			throw new removeFailedException("Bill removal failed !!!");	
		}
		else
		{
			String msg=service.removeBill(bill);
			return new ResponseEntity<String>(msg,HttpStatus.OK);
		}
	}
	
	
	@GetMapping("/viewBillByBillId/{id}")
	public ResponseEntity<Bill> viewBillById(@PathVariable int id) throws IdNotFoundException
	{ 
		Bill bill2=service.viewBillById(id);
		if(bill2==null)
		{
			throw new IdNotFoundException("Bill Id not found !!!");
		}
		else
		{
			return new ResponseEntity<Bill>(bill2,HttpStatus.OK);
		}
	}
	
	
	@GetMapping("/viewBillByCustomerId/{id}")
	public ResponseEntity<List<Bill>>  viewBillsByCustomerId(@PathVariable int id) throws IdNotFoundException{
		
		List<Bill> billList = service. viewBillsByCustomerId(id);
		if(billList==null)
		{
			throw new IdNotFoundException("Invalid customer Id !!!");
		}
		else
		{
			return new ResponseEntity<List<Bill>>(billList, HttpStatus.OK);
		}
	}
	
	
	@GetMapping("/viewBillByOrderDate/{startDate}/{endDate}")
	
	public ResponseEntity<List<Bill>> viewBillsBetweenDates(@PathVariable String startDate, @PathVariable String endDate){
		
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate startDate1 = LocalDate.parse(startDate, dateTimeFormatter);
		LocalDate endDate1 = LocalDate.parse(endDate, dateTimeFormatter);
		List<Bill> billList = service.viewBillsBetweenDates(startDate1,endDate1);
	
		return new ResponseEntity<List<Bill>>(billList, HttpStatus.OK);
	}
	
	
	@GetMapping("/calculateTotalCost/{id}")
	public ResponseEntity<String> calculateTotalCost(@PathVariable int id) throws IdNotFoundException{
		
		Bill bill=service.viewBillById(id);
		if(bill==null)
		{
			throw new IdNotFoundException("Unable to calculate Total cost due to invalid Bill Id...");
		}
		else
		{
			String billList = service.calculateTotalCost(bill);
		    return new ResponseEntity<String>(billList, HttpStatus.OK);
		}
		    
	}
}

