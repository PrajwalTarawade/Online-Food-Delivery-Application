package com.cg.fds.exceptions;

public class distinctRestaurantException extends Exception {
	
	public distinctRestaurantException(String msg)
	{
		super(msg);
	}

}
