package com.cg.fds.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fds.entities.Customer;
import com.cg.fds.entities.CustomerLogin;
import com.cg.fds.entities.FoodCart;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.repositories.ICartRepository;
import com.cg.fds.repositories.ICustomerLoginRepository;


@Service
@Transactional
public class CustomerLoginService implements ICustomerLogin {
	
	@Autowired
	ICustomerLoginRepository repository;
	
	@Autowired
	ICartRepository  repository2;
	
	@Override
	public CustomerLogin addCustomerLogin(CustomerLogin login) {
	repository.save(login);
		return login;
	}

	@Override
	public java.util.List<CustomerLogin> deleteCustomerLogin(int userid) throws removeFailedException {
		CustomerLogin login=repository.findById(userid).orElse(null);
		if(login==null)
		{
			throw new removeFailedException("Customer login removal failed !!!");
		}
		repository.deleteById(userid);
		return repository.findAll();
	}
	@Override
	public String CustomerLogin(String username, String password) {
		CustomerLogin r=repository.findByUserName(username);
		String pwd=r.getPassword();
		String login1="Login Successfull";
		String loginFail="Invalid Password";
		if(pwd.equals(password))
		{
			/*Customer customer=repository.getCustomer(username);
			FoodCart cart= new FoodCart();
			cart.setCustomer(customer);
			repository2.save(cart);*/
		     return null;//login1;
		}
		else
		{
			return loginFail;
		}
	}
	@Override
	public CustomerLogin updateCustomerLogin(CustomerLogin login) {
		repository.save(login);
		return login;	
	}
	@Override
	public String CustomerLogout() {
		String logout="Logout Successfull !!";
		return logout;
	}
	
}


