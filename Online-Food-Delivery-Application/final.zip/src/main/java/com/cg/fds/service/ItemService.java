package com.cg.fds.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fds.entities.Item;
import com.cg.fds.repositories.IItemRepository;

@Service
@Transactional
public class ItemService implements IItemService{

	@Autowired
	IItemRepository repository;
	
	@Override
	public Item addItem(Item item) {
		Item item1 = repository.save(item);	
		return item1;
	}

	@Override
	public Item updateItem(Item item) {
		
		Item item1=repository.save(item);
		return item1;
	}

	@Override
	public String removeItem(Item item) {
		
		repository.delete(item);
		return "Item removed successfully...";
	}

	@Override
	public List<Item> findItemsByRestaurant(String name) {
		
		List<Item> list=repository.findItemsByRestaurant(name);
		return list;		
	}

	@Override
	public List<Item> viewAllItemsByCategory(String name) {
		
		List<Item> list=repository.findItemsByCategory(name);
		return list;
		
	}

	@Override
	public List<Item> viewAllItemsByItemName(String name) {
		
		List<Item> list=repository.findItemsByItemName(name);
		return list;
	}

	
	@Override
	public Item viewItemById(int id) {
	
		Item item=repository.findById(id).orElse(null);
		return item;
	}

}
