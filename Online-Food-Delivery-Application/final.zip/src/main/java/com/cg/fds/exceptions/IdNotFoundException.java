package com.cg.fds.exceptions;

public class IdNotFoundException  extends Exception{
	
	public IdNotFoundException(String errorMessage)
	{
		super(errorMessage);
	}

}
