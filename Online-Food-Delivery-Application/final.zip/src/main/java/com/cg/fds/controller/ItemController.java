package com.cg.fds.controller;

import java.util.ArrayList;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fds.entities.Item;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.exceptions.invalidNameException;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.service.IItemService;

@RestController
public class ItemController 
{
	@Autowired
	IItemService itemservice;

	@PostMapping("/addItem")
	public ResponseEntity<Item> addItem(@Valid @RequestBody Item item)
	{
	    Item item2 =itemservice.addItem(item);
		return new ResponseEntity<Item>(item2,HttpStatus.OK);
	}
	
	@PutMapping("/updateItem")
	public ResponseEntity<Item> updateItem(@Valid @RequestBody Item item) throws IdNotFoundException
	{
		Item item1=itemservice.viewItemById(item.getItemId());
		if(item1==null)
		{
			throw new IdNotFoundException("Unable to update due to invalid Item Id  !!!");
		}
		else
		{
			Item item2 =itemservice.updateItem(item);
			return new ResponseEntity<Item>(item2,HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/removeItemById/{Item_id}")
	public ResponseEntity<String> removeItem(@PathVariable("Item_id") int iid) throws removeFailedException 
	{
		System.err.println(iid);
		Item item=itemservice.viewItemById(iid);
		if(item==null)
		{
			throw new removeFailedException("Unable to delete due to invalid Item Id !!!");
		}
		else
		{
			String msg=itemservice.removeItem(item);
			return new ResponseEntity<String>(msg, HttpStatus.OK);
		}
	}
	
	@GetMapping("/viewItemByItemId/{Item_id}")
	public ResponseEntity<Item> viewItemById(@PathVariable("Item_id") int iid) throws IdNotFoundException 
	{
		Item item = itemservice.viewItemById(iid);
		return new ResponseEntity<Item>(item, HttpStatus.OK);
		
	}

	@GetMapping("/viewAllItemsByCategory/{Category_name}")
	public ResponseEntity<List<Item>> viewAllItemsByCategory(@PathVariable("Category_name") String name) throws IdNotFoundException 
	{
		
		List<Item> item2 = itemservice.viewAllItemsByCategory(name); 
		if(item2.isEmpty())
		{
			throw new IdNotFoundException("Item id not found !!!");
		}
        return new ResponseEntity<List<Item>>(item2, HttpStatus.OK);
      }
	
	@GetMapping("/viewAllItemsByItemName/{Item_name}")
	public ResponseEntity<List<Item>> viewAllItemsByItemName(@PathVariable("Item_name") String name) throws invalidNameException
	{
		List<Item> items = itemservice.viewAllItemsByItemName(name); 
		if(items.isEmpty())
		{
			throw new invalidNameException("Item name not found !!!");
		}
        return new ResponseEntity<List<Item>>(items, HttpStatus.OK);
      }
	
	@GetMapping("/findItemsByRestaurant/{Restaurant_name}")
	public ResponseEntity<List<Item>> findItemsByRestaurant(@PathVariable("Restaurant_name") String name) throws invalidNameException
	{
		List<Item> items = itemservice.findItemsByRestaurant(name); 
		if(items.isEmpty())
		{
			throw new invalidNameException("Item name not found !!!");
		}
        return new ResponseEntity<List<Item>>(items, HttpStatus.OK);
      }
	
	
}


