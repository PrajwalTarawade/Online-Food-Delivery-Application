package com.cg.fds.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.Item;
import com.cg.fds.repositories.ICartRepository;
import com.cg.fds.repositories.IItemRepository;

@Service
@Transactional
public class CartService implements ICartService{

	@Autowired
	ICartRepository repository;
	
	@Autowired
	IItemRepository repository2;
	
	public CartService() {
		super();
		
	}

	@Override
	public FoodCart addItemToCart(int cartId, int itemId) {
		
		FoodCart cart=repository.findById(cartId).orElse(null);
		FoodCart cart1=new FoodCart();
		Item item=repository2.findById(itemId).orElse(null);
		int size=cart.getItemList().size();
		if(size==0)
		{
			cart.getItemList().add(item);
		    cart1=repository.save(cart);			
		}
		else
		{
			int new_rid=item.getRestaurant().getRestaurantId();
			int old_rid=cart.getItemList().get(0).getRestaurant().getRestaurantId();
			if(new_rid==old_rid)
			{
				//item.setQuantity(1);
				cart.getItemList().add(item);
			    cart1=repository.save(cart);
			}
			else
			{
				return null;
			}
		}
		return cart1;
	}

	@Override
	public FoodCart increaseQuantity(int cart_id,int item_id, int quantity) {
		
		FoodCart cart=repository.findById(cart_id).orElse(null);
		int cnt=0;
		List<Item> list=cart.getItemList();
		for(int i=0;i<quantity;i++)
		{
			int crr=list.get(i).getItemId();
			if(crr==item_id)
			{
				addItemToCart(cart_id, item_id);
				cnt++;
			}
		}
		if(cnt==0)
		{
			return null;
		}
		else
		{
			return cart;
		}
	}

	@Override
	public FoodCart reduceQuantity(Item item, int quantity) {
		
		/*FoodCart cart=item.getCart();
		List<Item> list=cart.getItemList();
		int qty=item.getQuantity();
		item.setQuantity(qty+quantity);
		list.add(item);*/
		return null;//repository.save(cart);
	}

	@Override
	public String removeItem(FoodCart cart, Item item) {
		List<Item> list=cart.getItemList();
		int id=item.getItemId();
		for(int i=0;i<list.size();i++)
		{
			if(id==list.get(i).getItemId())
			{
				list.remove(i);
			}
		}
		cart.setItemList(list);
		repository.save(cart);
		return "Item removed successfully...";
	}
	
	@Override
	public String clearCart(int cartId) {
		FoodCart cart=repository.findById(cartId).orElse(null);
		List<Item> item=cart.getItemList();
		item.clear();
		return "Cart cleared....";
	}

	@Override
	public FoodCart getCartById(int cartId) {
		System.out.println(cartId);
		FoodCart cart=repository.findById(cartId).orElse(null);
		System.err.println(cart);
		return cart;
	}

	@Override
	public Item getItemById(int itemId) {
		return repository2.findById(itemId).orElse(null);
	}

}
