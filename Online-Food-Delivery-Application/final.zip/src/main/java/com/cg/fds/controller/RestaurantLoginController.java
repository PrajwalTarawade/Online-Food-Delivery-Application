package com.cg.fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fds.entities.RestaurantLogin;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.service.IRestaurantLogin;
import com.cg.fds.service.RestaurantLoginService;


@RestController
public class RestaurantLoginController {
		
		@Autowired
		IRestaurantLogin service;
		
		@PostMapping("/addRestLogin")
		public ResponseEntity<RestaurantLogin> addRestaurantLogin(@RequestBody RestaurantLogin login) {
					RestaurantLogin loginData = service.addRestaurantLogin(login);
			return new ResponseEntity<RestaurantLogin>(loginData, HttpStatus.OK);
		}
		
		@PutMapping("/updateRestLogin")
		public ResponseEntity<RestaurantLogin> updateRestaurantLogin(@RequestBody RestaurantLogin login) {
			RestaurantLogin loginData = service.updateRestaurantLogin(login);
			return new ResponseEntity<RestaurantLogin>(loginData, HttpStatus.OK);
		}
		
		@DeleteMapping("/deleteRestLogin/{userid}")
		public ResponseEntity<List<RestaurantLogin>> deleteRestaurantLogin(@PathVariable int userid) throws removeFailedException {
			List<RestaurantLogin> restList = service.deleteRestaurantLogin(userid);
			return new ResponseEntity<List<RestaurantLogin>>(restList, HttpStatus.OK);
		}
		@GetMapping("/restaurantLogin/{username}/{password}")
		public ResponseEntity<String> candidateLogin(@PathVariable String username,@PathVariable String password) 
		{
			String login=service.candidateLogin(username,password);
			return new ResponseEntity<String>(login, HttpStatus.OK);
		}
		
		@GetMapping("/restaurantLogout")
		public ResponseEntity<String> candidateLogout() 
		{
			String logout=service.candidateLogout();
			return new ResponseEntity<String>(logout, HttpStatus.OK);
		}
}