package com.cg.fds.exceptions;

public class invalidItemNameException extends Exception {
	
	public invalidItemNameException(String msg)
	{
		super(msg);
	}

}
