package com.cg.fds.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fds.entities.Item;
import com.cg.fds.entities.Restaurant;
import com.cg.fds.repositories.IItemRepository;
import com.cg.fds.repositories.IRestaurantRepository;

@Service
@Transactional
public class RestaurantService implements IRestaurantService {

	@Autowired
	IRestaurantRepository repository;
	
	@Autowired
	IItemRepository repo2;
	
	@Override
	public Restaurant addRestaurant(Restaurant res) {
		
		repository.save(res);
		return res;
	}

	@Override
	public Restaurant updateRestaurant(Restaurant restaurant) {
				
		repository.save(restaurant);
		return restaurant;
	}
	
	@Override
	public String removeRestaurantById(int Rid) {
		
		Restaurant rest=repository.findById(Rid).orElse(null);
		List<Item> list=repo2.findItemsByRestaurant(rest.getRestaurantName());
		for(int i=0;i<list.size();i++)
		{
			Item item=list.get(i);
			int id=item.getItemId();
			repo2.deleteById(id);
		}
		repository.deleteById(Rid);
		
		String msg="Remove restaurant successfull !!!";
		return msg;
	}

	@Override
	public List<Restaurant> viewAllRestaurants() {
		
		List<Restaurant> list=repository.findAll();
		return list;
	}
	
	@Override
	public Restaurant viewRestaurantById(int id) {
		
		Restaurant restaurant = repository.findById(id).orElse(null);
		return restaurant;	
	}


	@Override
	public List<Restaurant> viewNearByRestaurant(String location) {
		
		List<Restaurant> list = repository.viewNearByRestaurant(location);
		return list;
	}


	@Override
	public List<Restaurant> viewRestaurantByItemName(String restaurantName) {
		
		List<Integer> list=repository.viewRestaurantByItemName(restaurantName);
		List<Restaurant> list2=new ArrayList<Restaurant>();
		for(int i=0;i<list.size();i++)
		{
			Restaurant rest=repository.findById(list.get(i)).orElse(null);
			list2.add(rest);
		}
		System.err.println(list2);
		return list2;
	}

}
