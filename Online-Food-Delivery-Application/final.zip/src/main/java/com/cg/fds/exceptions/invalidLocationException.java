package com.cg.fds.exceptions;

public class invalidLocationException extends Exception {

	public invalidLocationException(String msg)
	{
		super(msg);
	}
}
