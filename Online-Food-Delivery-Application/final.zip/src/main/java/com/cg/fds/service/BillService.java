package com.cg.fds.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fds.entities.Item;
import com.cg.fds.entities.Bill;
import com.cg.fds.entities.Customer;
import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.OrderDetails;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.repositories.IBillRepository;
import com.cg.fds.repositories.IOrderRepository;

@Service
@Transactional
public class BillService implements IBillService {
	
	@Autowired
    IBillRepository repository;
	
	@Autowired
	IOrderRepository repository2;
	
	
	Customer customer;
	FoodCart foodCart;
	Item item;
	
	@Override
	public Bill addBill(int id) {
	    
		Bill bill=new Bill();
		/*OrderDetails order=repository2.findById(id).orElse(null);
		List<Item> list=order.getList();	
		//System.out.println(list);
		int total_item=list.size();
		int sum=0;
		for(int i=0;i<total_item;i++)
		{
			Item item=list.get(i);
			sum+=item.getCost();
		}
		
		bill.setBillDate(order.getOrderDate());
		bill.setOrder(order);
		//System.out.println(order);
		bill.setTotalItem(total_item);
		bill.setTotalCost(sum);*/
		
		repository.save(bill);
		System.err.println(bill);
		return bill;
	}

	@Override
	public String removeBill(Bill bill) {
		
		repository.delete(bill);
		String msg="Bill removed Succesfully";
		return msg;
	}

	@Override
	public Bill viewBillById(int id) {
		
		Bill bill=repository.findById(id).orElse(null);
		return bill;
		
	}

	@Override
	public List<Bill> viewBillsBetweenDates(LocalDate startDate, LocalDate endDate) {
        
		LocalDateTime startDateTime = startDate.atTime(0,0, 0);
        LocalDateTime endDateTime = endDate.atTime(23,59,59);
        List<Bill> bill1= new ArrayList<Bill>();
        /*List<Integer> bill=repository.findByBillDates(startDateTime, endDateTime);
        for(int i = 0; i < bill.size(); i++){
           int id=bill.get(i);
           Bill b=repository.findById(id).orElse(null);
           System.out.println(b);
           bill1.add(b);           
        }*/
        return null;//bill1;
    }

	@Override
	public List<Bill> viewBillsByCustomerId(int custId) {
		
		List<Bill> bill1= new ArrayList<Bill>();	
		/*List<Integer> bill=repository.findByCustId(custId);
		for(int i = 0; i < bill.size(); i++){
		   int id=bill.get(i);
		   Bill b=repository.findById(id).orElse(null);
		   System.out.println(b);
		   bill1.add(b);		   
		}*/
        return null;//bill1;
	}

	@Override
	public String calculateTotalCost(Bill bill) {
		
		/*Double totalCost=bill.getTotalCost();
		StringBuffer sb=new StringBuffer("Total cost of bill is ");
		sb.append(totalCost);
		String msg=sb.toString();*/
		return null;//msg;
	}
	
}
