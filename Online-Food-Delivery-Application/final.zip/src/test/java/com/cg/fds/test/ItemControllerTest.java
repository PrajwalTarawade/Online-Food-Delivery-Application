package com.cg.fds.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.fds.entities.Address;
import com.cg.fds.entities.Category;
import com.cg.fds.entities.Customer;
import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.Item;
import com.cg.fds.entities.Restaurant;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.repositories.ICustomerRepository;
import com.cg.fds.repositories.IItemRepository;
import com.cg.fds.service.ICustomerService;
import com.cg.fds.service.IItemService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ItemControllerTest {
	
	@Autowired  
	IItemService service;
		
	@MockBean
	IItemRepository repository;  
	
	@Test
	public void addItemTest()
	{
		Item item = getItem();
		Mockito.when(repository.save(item)).thenReturn(item);
		assertEquals(item,service.addItem(item));
	}
	
	@Test
	public void updateItemTest()
	{
		Item item = getItem();
		Mockito.when(repository.save(item)).thenReturn(item);
		Item result=service.updateItem(item);
		assertEquals(item,result);
	}
	
	@Test
	public void findById() throws IdNotFoundException
	{
		Item item = getItem();
		service.viewItemById(item.getItemId());  
		verify(repository, times(1)).findById(item.getItemId());
	}
	
	@Test
	public void deleteItemTest() throws removeFailedException 
	{
		Item item = getItem();
		String msg="Item removed successfully...";
		Mockito.when(repository.save(item)).thenReturn(item);
		String result=service.removeItem(item);
		assertEquals(msg,result);
		//verify(repository, times(2)).deleteById(cust.getCustomerId());
	}
	
	@Before
	public Item getItem()
	{
		Item item = new Item(); 
		//item.setRestaurant(getRestaurant());
		item.setItemId(20);
		item.setItemName("Biryani");
		item.setQuantity(1);
		item.setCost(250);
		
		return item;
	}
	
	@Before
	public Restaurant getRestaurant()
	{
		Restaurant rest=new Restaurant();
		rest.setRestaurantId(1);
		rest.setRestaurantName("Savali");
		return rest;
	}
	
	@Before
	public Category getCategory()
	{
		Category cat = new Category();
		cat.setCatId(10);
		cat.setCategoryName("Veg");
		return cat;
	}
	
	@Before
	public FoodCart getFoodCart()
	{
		FoodCart cart = new FoodCart();
		cart.setCartId(5);
		return cart;
	}

}
