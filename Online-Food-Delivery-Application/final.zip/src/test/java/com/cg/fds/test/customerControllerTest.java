package com.cg.fds.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.fds.entities.Address;
import com.cg.fds.entities.Customer;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.repositories.ICustomerRepository;
import com.cg.fds.service.ICustomerService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class customerControllerTest {
	
	@Autowired  
	ICustomerService service;
		
	@MockBean
	ICustomerRepository repository;  
	
	@Test
	public void addCustomerTest()
	{
		Customer cust = getCustomer();
		Mockito.when(repository.save(cust)).thenReturn(cust);
		assertEquals(cust,service.addCustomer(cust));
	}
	
	@Test
	public void updateCustomerTest()
	{
		Customer cust = getCustomer();
		Mockito.when(repository.save(cust)).thenReturn(cust);
		Customer result=service.updateCustomer(cust);
		assertEquals(cust,result);
	}
	
	@Test
	public void findById() throws IdNotFoundException
	{
		Customer cust = getCustomer();
		service.viewCustomerById(cust.getCustomerId());  
		verify(repository, times(1)).findById(cust.getCustomerId());
	}
	
	@Test
	public void deleteCustomerTest() throws removeFailedException 
	{
		Customer cust = getCustomer();
		String msg="Customer Removed successfully...";
		Mockito.when(repository.save(cust)).thenReturn(cust);
		String result=service.removeCustomerById(cust.getCustomerId());
		assertEquals(msg,result);
		//verify(repository, times(2)).deleteById(cust.getCustomerId());
	}
	
	public Customer getCustomer()
	{
		Customer cust=new Customer();
		cust.setAddress(getAddress());
		cust.setAge(22);
		cust.setCustomerId(10);
		cust.setEmail("Amit@gmail.com");
		cust.setFirstName("Amit");
		cust.setGender("M");
		cust.setLastName("Shinde");
		cust.setMobileNumber("987456242");
		return cust;
	}
	
	
	public Address getAddress()
	{
		Address add=new Address();
		add.setAddressId(2);
		add.setArea("Hadapsar");
		add.setBuildingName("Pebble");
		add.setCity("Pune");
		add.setCountry("India");
		add.setPincode("41160");
		add.setState("Maharashtra");
		add.setStreetNo("93");
		return add;
	}
}