package com.cg.fds.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.fds.entities.Address;
import com.cg.fds.entities.Restaurant;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.repositories.IRestaurantRepository;
import com.cg.fds.service.IRestaurantService;

@RunWith(SpringRunner.class)
@SpringBootTest

public class RestaurantControllerTest {


	@Autowired  
	IRestaurantService service;
		
	@MockBean
	IRestaurantRepository repository;  
	
	@Test
	public void addRestaurantTest()
	{
		Restaurant restaurant= getRestaurant();
		Mockito.when(repository.save(restaurant)).thenReturn(restaurant);
		assertEquals(restaurant, service.addRestaurant(restaurant));
	}
	
	@Test
	public void updateRestaurantTest()
	{
		Restaurant restaurant= getRestaurant();

		Mockito.when(repository.save(restaurant)).thenReturn(restaurant);
		Restaurant restaurant1 = service.updateRestaurant(restaurant);
		assertEquals(restaurant, restaurant1);
	}
	
	@Test
	public void findById() throws IdNotFoundException
	{
		Restaurant restaurant = getRestaurant();

		service.viewRestaurantById(restaurant.getRestaurantId());
		verify(repository, timeout(1)).findById(restaurant.getRestaurantId());
	}
	
	@Test
	public void deleteRsetaurantTest() throws removeFailedException 
	{
		Restaurant restaurant = getRestaurant();		
		String msg="Remove restaurant failed !!!";
		Mockito.when(repository.save(restaurant)).thenReturn(restaurant);
		String result=service.removeRestaurantById(restaurant.getRestaurantId());
		assertEquals(msg,result);
		//verify(repository, times(2)).deleteById(cust.getCustomerId());
	}
	
	public Restaurant getRestaurant()
	{
		Restaurant restaurant = new Restaurant();
		restaurant.setAddress(getAddress());
		restaurant.setRestaurantId(1);
		restaurant.setRestaurantName("Ashoka Dhaba");
		restaurant.setManagerName("Dhanashree");
		restaurant.setContactNumber("9876543210");
		//restaurant.setItemList(null);

		return restaurant;
	}
	
	
	public Address getAddress()
	{
		Address add=new Address();
		add.setAddressId(2);
		add.setArea("Hadapsar");
		add.setBuildingName("Pebble");
		add.setCity("Pune");
		add.setCountry("India");
		add.setPincode("41160");
		add.setState("Maharashtra");
		add.setStreetNo("93");
		return add;
	}
}
