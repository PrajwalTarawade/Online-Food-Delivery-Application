package com.cg.fds.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.fds.entities.Category;
import com.cg.fds.entities.Customer;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.repositories.ICategoryRepository;
import com.cg.fds.service.ICategoryService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class categoryControllerTest {

	@Autowired
	ICategoryService service;
	
	@MockBean
	ICategoryRepository repository;
	
	@Test
	public void addCategoryTest()
	{
		Category category = getCategory();
		Mockito.when(repository.save(category)).thenReturn(category);
		assertEquals(category,service.addCategory(category));
	}
	
	@Test
	public void updateCategoryTest()
	{
		Category category = getCategory();
		Mockito.when(repository.save(category)).thenReturn(category);
		Category result=service.updateCategory(category);
		assertEquals(category,result);
	}
	
	@Test
	public void findById() throws IdNotFoundException
	{
		Category category = getCategory();
		service.viewCategoryById(category.getCatId());  
		verify(repository, times(1)).findById(category.getCatId());
	}
	
	@Test
	public void deleteCategoryTest() throws removeFailedException 
	{
		Category category = getCategory();
		String msg="Category removed successfully...";
		Mockito.when(repository.save(category)).thenReturn(category);
		String result=service.removeCategory(category);
		assertEquals(msg,result);
		//verify(repository, times(1)).deleteById(category.getCatId());
	}
	
	public Category getCategory()
	{
		Category category= new Category();
		category.setCatId(1);
		category.setCategoryName("Veg");
		
		return category;
	}
}














