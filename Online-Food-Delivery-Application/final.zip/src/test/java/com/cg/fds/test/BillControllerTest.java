package com.cg.fds.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.fds.entities.FoodCart;
import com.cg.fds.entities.Address;
import com.cg.fds.entities.Bill;
import com.cg.fds.entities.Customer;
import com.cg.fds.entities.OrderDetails;
import com.cg.fds.exceptions.IdNotFoundException;
import com.cg.fds.exceptions.removeFailedException;
import com.cg.fds.repositories.IBillRepository;
import com.cg.fds.service.IBillService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BillControllerTest {
	
	@Autowired  
	IBillService service;
		
	@MockBean
	IBillRepository repository;  
	
	@Test
	public void addBillTest()
	{
		Bill bill = getBill();
		Mockito.when(repository.save(bill)).thenReturn(bill);
		//assertEquals(bill,service.addBill(bill));
	}
	
/*	@Test
	public void updateCustomerTest()
	{
		Bill bill = getBill();
		Mockito.when(repository.save(bill)).thenReturn(bill);
		Customer result=service.updateCustomer(bill);
		assertEquals(bill,result);
	}*/
	
	@Test
	public void findById() throws IdNotFoundException
	{
		Bill bill = getBill();
		service.viewBillById(bill.getBillId());  
		verify(repository, times(1)).findById(bill.getBillId());
	}
	
	/*@Test
	public void findByCustId() throws IdNotFoundException
	{
		//Bill bill = getBill();
		Customer cust=getCustomer();
		service.viewBillsByCustomerId(cust.getCustomerId());  
		verify(repository, times(1)).findByCustId(cust.getCustomerId());
	}*/
	
	@Test
	public void deleteBillTest() throws removeFailedException 
	{
		Bill bill = getBill();
		String msg="Bill removed Succesfully";
		Mockito.when(repository.save(bill)).thenReturn(bill);
		String result=service.removeBill(bill);
		assertEquals(msg,result);
	
	}
	/*@Test
	public void findByLocalDate() throws IdNotFoundException
	{
		Bill bill = getBill();
		LocalDate startDate = LocalDate.of(2019, 1, 8);
		LocalDate endDate = LocalDate.of(2022, 1, 8);
		LocalDateTime startDateTime = startDate.atTime(0,0, 0);
		LocalDateTime endDateTime = endDate.atTime(23,59,59);
		service.viewBillsBetweenDates(startDate,endDate);  
		verify(repository, times(1)).findByBillDates(startDateTime,endDateTime);
	}*/
	
	@Test
	public void calculateTotalCostTest() throws IdNotFoundException 
	{
		Bill bill=getBill();
		Double cost=bill.getTotalCost();
		StringBuffer sb=new StringBuffer("Total cost of bill is ");
		sb.append(cost);
		String res=sb.toString();
		String result=service.calculateTotalCost(bill);
		assertEquals(res,result);
	}
	public Bill getBill()
	{
		Bill bill=new Bill();
		bill.setOrder(getOrderDetails());
		bill.setTotalItem(1);
		bill.setTotalCost(200);
		LocalDateTime now = LocalDateTime.now();
		bill.setBillDate(now);
		return bill;
	}
	
	
	public OrderDetails getOrderDetails()
	{
		OrderDetails order=new OrderDetails();
		LocalDateTime now = LocalDateTime.now();
		//order.setCart(null);
		order.setOrderDate(now);
		order.setOrderStatus("Delivered");
		return order;
	}
	public FoodCart getFoodCart() {
		FoodCart fc=new FoodCart();
		fc.setCartId(1);
		fc.setCustomer(getCustomer());
		fc.setItemList(null);
		return fc;
	}
	public Customer getCustomer()
	{
		Customer cust=new Customer();
		cust.setAddress(getAddress());
		cust.setAge(22);
		cust.setCustomerId(10);
		cust.setEmail("Amit@gmail.com");
		cust.setFirstName("Amit");
		cust.setGender("M");
		cust.setLastName("Shinde");
		cust.setMobileNumber("987456242");
		return cust;
	}
	public Address getAddress()
	{
		Address add=new Address();
		add.setAddressId(2);
		add.setArea("Hadapsar");
		add.setBuildingName("Pebble");
		add.setCity("Pune");
		add.setCountry("India");
		add.setPincode("41160");
		add.setState("Maharashtra");
		add.setStreetNo("93");
		return add;
	}
}